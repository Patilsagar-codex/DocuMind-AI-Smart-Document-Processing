import json
import sqlite3
from pathlib import Path
DB = Path("documind_history.db")

def init_db():
    with sqlite3.connect(DB) as conn:
        conn.execute("""CREATE TABLE IF NOT EXISTS documents (
            id INTEGER PRIMARY KEY AUTOINCREMENT, label TEXT NOT NULL, filename TEXT NOT NULL,
            document_type TEXT NOT NULL, word_count INTEGER NOT NULL, fields_json TEXT NOT NULL,
            extracted_text TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP)""")

def save_document(label, filename, result):
    with sqlite3.connect(DB) as conn:
        conn.execute("""INSERT INTO documents
            (label, filename, document_type, word_count, fields_json, extracted_text)
            VALUES (?, ?, ?, ?, ?, ?)""",
            (label, filename, result["document_type"], result["word_count"],
             json.dumps(result["fields"]), result["text"]))

def list_documents():
    with sqlite3.connect(DB) as conn:
        conn.row_factory = sqlite3.Row
        return [dict(r) for r in conn.execute(
            "SELECT id,label,filename,document_type,word_count,extracted_text AS text,created_at FROM documents ORDER BY id DESC"
        ).fetchall()]

def get_document(doc_id):
    with sqlite3.connect(DB) as conn:
        conn.row_factory = sqlite3.Row
        row = conn.execute("SELECT * FROM documents WHERE id=?", (doc_id,)).fetchone()
        if not row:
            return None
        item = dict(row)
        item["fields"] = json.loads(item.pop("fields_json"))
        item["text"] = item.pop("extracted_text")
        return item
