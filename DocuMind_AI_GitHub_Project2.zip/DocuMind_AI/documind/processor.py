import io
import re
from pathlib import Path
from pypdf import PdfReader
from PIL import Image
import pytesseract

def extract_text(filename, data):
    ext = Path(filename).suffix.lower()
    if ext == ".pdf":
        text = "\\n".join(page.extract_text() or "" for page in PdfReader(io.BytesIO(data)).pages).strip()
        if text:
            return text
        try:
            from pdf2image import convert_from_bytes
            return "\\n".join(pytesseract.image_to_string(page) for page in convert_from_bytes(data)).strip()
        except ImportError as exc:
            raise RuntimeError("Scanned PDF OCR needs pdf2image and Poppler. Try a text-based PDF or image.") from exc
    if ext in {".png", ".jpg", ".jpeg"}:
        return pytesseract.image_to_string(Image.open(io.BytesIO(data))).strip()
    raise ValueError("Unsupported file type.")

def classify_document(text):
    t = text.lower()
    rules = {
        "Invoice": ["invoice", "bill to", "tax invoice", "total due", "gstin", "subtotal"],
        "Resume": ["resume", "curriculum vitae", "work experience", "education", "skills"],
        "Report": ["executive summary", "introduction", "conclusion", "findings", "report"]
    }
    scores = {kind: sum(word in t for word in words) for kind, words in rules.items()}
    best = max(scores, key=scores.get)
    return best if scores[best] else "Other"

def first_match(patterns, text):
    for pattern in patterns:
        match = re.search(pattern, text, re.I | re.M)
        if match:
            return match.group(1).strip(" \\t:#")
    return None

def invoice_fields(text):
    return {
        "invoice_number": first_match([r"(?:invoice\\s*(?:no|number|#)|bill\\s*(?:no|number))\\s*[:#-]?\\s*([A-Z0-9/-]+)"], text),
        "invoice_date": first_match([r"(?:invoice\\s*date|date)\\s*[:#-]?\\s*(\\d{1,2}[/-]\\d{1,2}[/-]\\d{2,4}|\\d{4}-\\d{2}-\\d{2})"], text),
        "vendor": first_match([r"(?:vendor|seller|supplier)\\s*[:#-]?\\s*([^\\n]+)"], text),
        "total_amount": first_match([r"(?:grand\\s*total|total\\s*amount|amount\\s*due|total)\\s*[:₹$ ]+\\s*([₹$]?\\s*[\\d,]+(?:\\.\\d{1,2})?)"], text),
        "tax_id": first_match([r"(?:GSTIN|GST\\s*IN)\\s*[:#-]?\\s*([0-9A-Z]{10,20})"], text)
    }

def process_document(filename, data):
    text = extract_text(filename, data)
    if not text.strip():
        raise ValueError("No readable text found. Try a clearer image or text-based PDF.")
    kind = classify_document(text)
    words = re.findall(r"\\b[\\w'-]+\\b", text)
    return {"text": text, "document_type": kind, "word_count": len(words),
            "fields": invoice_fields(text) if kind == "Invoice" else {}}
