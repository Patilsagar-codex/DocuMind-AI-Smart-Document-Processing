# DocuMind AI — Smart Document Processing System

A Python portfolio project that extracts text from PDFs and images, classifies documents, detects common invoice fields, and stores results in SQLite.

## Features
- Text extraction from text-based PDF files using PyPDF
- OCR for PNG/JPG using Tesseract
- Optional OCR for scanned PDFs using pdf2image and Poppler
- Rule-based classification: Invoice, Resume, Report or Other
- Regex-based extraction of invoice number, date, vendor, total and GSTIN
- SQLite history and search interface

## Tech stack
Python, Streamlit, OCR, Tesseract, PyPDF, Regular Expressions, SQLite

## Run locally
1. Install Python 3.10 or newer.
2. Create and activate a virtual environment:
   `python -m venv .venv`
3. Activate it:
   Windows: `.venv\\Scripts\\activate`
   macOS/Linux: `source .venv/bin/activate`
4. Install dependencies: `pip install -r requirements.txt`
5. Install Tesseract OCR separately:
   Ubuntu: `sudo apt install tesseract-ocr`
   macOS: `brew install tesseract`
   Windows: install Tesseract and add it to PATH.
6. Start: `streamlit run app.py`

For scanned PDFs, install Poppler too (Ubuntu: `sudo apt install poppler-utils`; macOS: `brew install poppler`). Text-based PDFs do not need OCR.

## Limitations
Classification currently uses transparent keyword rules, not a trained deep-learning model. Invoice field extraction uses regular expressions and may not work with every layout. OCR quality depends on scan clarity. Always verify extracted financial details manually. This demo stores data locally and is not designed for confidential production documents.

## Future improvements
Train and evaluate an ML classifier, add multilingual OCR, layout-aware extraction, authentication, automated tests, and CSV/Excel export.

## Author
Sagar Patil
