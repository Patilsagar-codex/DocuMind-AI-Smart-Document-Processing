import streamlit as st
from documind.database import init_db, save_document, list_documents, get_document
from documind.processor import process_document

st.set_page_config(page_title="DocuMind AI", page_icon="📄", layout="wide")
init_db()
st.title("📄 DocuMind AI")
st.caption("Smart document processing, OCR, classification and information extraction")

tab1, tab2, tab3 = st.tabs(["Process document", "History", "Search"])
with tab1:
    upload = st.file_uploader("Upload PDF, PNG or JPG", type=["pdf", "png", "jpg", "jpeg"])
    label = st.text_input("Document label (optional)")
    if upload and st.button("Process document", type="primary"):
        try:
            st.session_state.result = process_document(upload.name, upload.getvalue())
            st.session_state.filename = upload.name
            st.success("Document processed.")
        except Exception as e:
            st.error(str(e))
    result = st.session_state.get("result")
    if result:
        a, b = st.columns(2)
        a.metric("Detected type", result["document_type"])
        b.metric("Word count", result["word_count"])
        st.subheader("Extracted invoice fields")
        st.json(result["fields"])
        st.text_area("Extracted text", result["text"], height=250)
        if st.button("Save to history"):
            save_document(label or st.session_state.filename, st.session_state.filename, result)
            st.success("Saved in local SQLite database.")
with tab2:
    rows = list_documents()
    if rows:
        st.dataframe([{"ID": r["id"], "Label": r["label"], "Filename": r["filename"],
                       "Type": r["document_type"], "Words": r["word_count"], "Saved": r["created_at"]}
                      for r in rows], use_container_width=True, hide_index=True)
        doc_id = st.number_input("Document ID to open", min_value=1, step=1)
        if st.button("Open saved document"):
            item = get_document(int(doc_id))
            if item:
                st.write(item["label"], "—", item["document_type"])
                st.json(item["fields"])
                st.text_area("Saved text", item["text"], height=220)
            else:
                st.warning("Document ID not found.")
    else:
        st.info("No documents saved yet.")
with tab3:
    query = st.text_input("Search saved documents")
    if query.strip():
        matches = [r for r in list_documents() if query.lower() in
                   (r["label"] + " " + r["filename"] + " " + r["document_type"] + " " + r["text"]).lower()]
        for item in matches:
            st.markdown(f"**{item['label']}** · {item['document_type']} · ID {item['id']}")
            st.write(item["text"][:400])
            st.divider()
        if not matches:
            st.info("No matching documents.")
